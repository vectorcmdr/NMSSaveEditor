package nomanssave;

public interface gD {
   String K();
}
