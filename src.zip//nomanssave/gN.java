package nomanssave;

public enum gN {
   rJ,
   rK,
   rL,
   rM;
}
