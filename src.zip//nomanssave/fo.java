package nomanssave;

public interface fo {
   boolean U(String var1);

   boolean V(String var1);

   fn L();

   fp[] bR();

   String j(eY var1);
}
