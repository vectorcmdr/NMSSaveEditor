package nomanssave;

class et {
   final String id;

   et(String var1) {
      this.id = var1;
   }

   public boolean equals(Object var1) {
      return this.id.equals(((er)var1).id);
   }
}
