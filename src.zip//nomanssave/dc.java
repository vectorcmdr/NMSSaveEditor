package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class dc implements ActionListener {
   // $FF: synthetic field
   final cY gR;

   dc(cY var1) {
      this.gR = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.gR.setVisible(false);
   }
}
