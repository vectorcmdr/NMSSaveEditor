package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class an implements ActionListener {
   // $FF: synthetic field
   final aj cg;

   an(aj var1) {
      this.cg = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.cg.setVisible(false);
   }
}
