package nomanssave;

public interface gQ {
   String getType();

   Object dz();

   default String ei() {
      Object var1 = this.dz();
      return var1 instanceof fg ? ((fg)var1).bP() : var1.toString();
   }

   void m(Object var1);

   int dA();

   void aA(int var1);

   int dB();
}
