package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class cc implements ActionListener {
   // $FF: synthetic field
   final bS fk;

   cc(bS var1) {
      this.fk = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      if (bO.a(bS.j(this.fk)).dr()) {
         bO.c(bS.j(this.fk));
      }

   }
}
