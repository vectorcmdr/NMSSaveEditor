package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class V implements ActionListener {
   // $FF: synthetic field
   final Q bD;

   V(Q var1) {
      this.bD = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.bD.setVisible(false);
   }
}
