package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class b implements ActionListener {
   // $FF: synthetic field
   final a b;

   b(a var1) {
      this.b = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.b.setVisible(false);
   }
}
