package nomanssave;

interface bK {
   String getID();

   boolean isSpecial();

   String ab();

   void l(String var1);
}
