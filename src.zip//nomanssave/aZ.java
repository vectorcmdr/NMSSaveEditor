package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class aZ implements ActionListener {
   // $FF: synthetic field
   final aW dy;

   aZ(aW var1) {
      this.dy = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.dy.setVisible(false);
   }
}
