package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class o implements ActionListener {
   // $FF: synthetic field
   final h z;

   o(h var1) {
      this.z = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.z.setVisible(false);
   }
}
