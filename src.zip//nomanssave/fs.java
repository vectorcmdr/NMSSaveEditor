package nomanssave;

public interface fs {
   String K();

   fn L();

   eY M();

   String b(eY var1);

   long lastModified();

   default String getName() {
      return null;
   }

   default String getDescription() {
      return null;
   }
}
