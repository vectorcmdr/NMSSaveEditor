package nomanssave;

public enum gd {
   nd,
   ne,
   nf;
}
