package nomanssave;

public interface cR {
   void setSelectedValue(String var1);
}
