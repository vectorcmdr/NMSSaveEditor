package nomanssave;

import java.util.Map;

public class fk extends eY {
   final eC li;

   fk(eC var1) {
      this.li = var1;
   }

   public Map bp() {
      return this.li.bp();
   }
}
