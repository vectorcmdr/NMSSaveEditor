package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class dh implements ActionListener {
   // $FF: synthetic field
   final dd gW;

   dh(dd var1) {
      this.gW = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.gW.setVisible(false);
   }
}
