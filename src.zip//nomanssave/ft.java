package nomanssave;

public interface ft {
   int getIndex();

   boolean isEmpty();

   fn L();

   fs[] bX();
}
