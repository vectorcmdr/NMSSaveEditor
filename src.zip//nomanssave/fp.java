package nomanssave;

public interface fp {
   String K();

   long lastModified();

   eY M();

   String b(eY var1);
}
