package nomanssave;

class fU extends fX implements fr {
   // $FF: synthetic field
   final fT mN;

   fU(fT var1) {
      super(var1, "AccountData");
      this.mN = var1;
   }

   public eY M() {
      return this.a(eG.jW);
   }

   public void k(eY var1) {
      this.a("msaccountdata", (fn)null);
      this.h(var1);
   }
}
