package nomanssave;

class fd extends RuntimeException {
   private fd() {
   }

   // $FF: synthetic method
   fd(fd var1) {
      this();
   }
}
