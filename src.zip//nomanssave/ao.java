package nomanssave;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ao implements ActionListener {
   // $FF: synthetic field
   final aj cg;

   ao(aj var1) {
      this.cg = var1;
   }

   public void actionPerformed(ActionEvent var1) {
      this.cg.setVisible(false);
   }
}
