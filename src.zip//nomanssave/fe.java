package nomanssave;

public interface fe {
   void propertyChanged(String var1, Object var2, Object var3);
}
