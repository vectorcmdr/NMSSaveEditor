package nomanssave;

public enum gi {
   no,
   np,
   nq,
   nr,
   ns,
   nt,
   nu,
   nv,
   nw,
   nx,
   ny,
   nz,
   nA,
   nB,
   nC,
   nD;
}
