package nomanssave;

public class W {
   final int bE;
   final int bF;

   W(int var1, int var2) {
      this.bE = var1;
      this.bF = var2;
   }
}
