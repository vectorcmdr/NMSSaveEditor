package nomanssave;

public enum gl {
   oF,
   oG;
}
