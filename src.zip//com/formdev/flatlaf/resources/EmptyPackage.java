package com.formdev.flatlaf.resources;

interface EmptyPackage {
}
