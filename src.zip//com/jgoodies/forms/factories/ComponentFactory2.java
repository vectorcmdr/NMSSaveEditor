package com.jgoodies.forms.factories;

import javax.swing.JLabel;

public interface ComponentFactory2 extends ComponentFactory {
   JLabel createReadOnlyLabel(String var1);
}
