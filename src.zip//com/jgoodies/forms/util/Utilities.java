package com.jgoodies.forms.util;

/** @deprecated */
public final class Utilities {
   private Utilities() {
   }

   /** @deprecated */
   public static boolean isLafAqua() {
      return FormUtils.isLafAqua();
   }
}
