No Man's Sky - Save Editor

To run this app, you must have Java 8 installed.
https://java.com/en/download/

Then simply run the NMSSaveEditor.bat file.

## Troubleshooting ##

If you notice anything unexpected happen while using the editor, such as crashes, try running the 4G executable instead.

For anything else, visit https://github.com/vectorcmdr/NMSSaveEditor and lodge an issue there, along with your NMSSaveEditor.log file (where appropriate).

Enjoy!